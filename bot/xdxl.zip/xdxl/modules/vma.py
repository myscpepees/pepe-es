from xdxl import *

@bot.on(events.CallbackQuery(data=b'cfg-vmess'))
async def config_vmess(event):
	async def config_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot cfvm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Is Not Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			#user = re.search("#(.*)",x[0]).group(1)
			iplim = re.search("@(.*?):",info[0])
			quota = re.search("#(.*?):",info[0])
			exp = re.search("&(.*?):",info[0])
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Config Xray/Vmess Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{z["ps"]}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{z["id"]}`
**» AlterId :** `0`
**» Security :** `auto`
**» NetWork :** `ws - grpc`
**» Path :** `/vmess`
**» ServiceName  :** `vmess`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS :** 
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link gRPC :** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vmess-{z["ps"]}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp}`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await config_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'cek-login vmess bot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```{z}```

🤖 **» t.me/nauracloud/30**
""",buttons=[[Button.inline("‹ Main Menu ›","vmess")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot delete vmess'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'lvm'))
async def lock_vmess(event):
	async def lock_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot lock vmess'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Locked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'uvm'))
async def unlock_vmess(event):
	async def unlock_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot unlock vmess'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Unlocked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vm-ip'))
async def ip_vmess(event):
	async def ip_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond('**Limit User (IP):**')
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		cmd = f'printf "%s\n" "{user}" "{iplim}" | sbot ipvm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit IP Vmess ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit IP:** `{iplim} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ip_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vm-quota'))
async def quota_vmess(event):
	async def quota_vmess_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as quota:
			await event.respond('**Limit Quota (GB):**')
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = (await quota).raw_text
		cmd = f'printf "%s\n" "{user}" "{quota}" | sbot qvm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit Quota Vmess ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit Quota:** `{quota} GB`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await quota_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'memvm'))
async def member_vmess(event):
	async def member_vmess_(event):
		cmd = 'vma member bot'.strip()
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Server Data`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**List Member Xray/Vmess Account**
🤖 **» t.me/nauracloud/30**
""",buttons=[[Button.inline("‹ Main Menu ›","vmess")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await member_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def vmess_renew(event):
	async def vmess_renew_(event):
		cmd2 = 'vma member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Perpanjang (Days):**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | sbot renew vmess'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Renew Vmess ⟩**
**━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Diperpanjang:** `{exp} Hari`
**━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_renew_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" Create Vmess ","create-vmess"),
Button.inline(" Triall Vmess ","trial-vmess")], 
[Button.inline(" Delete Vmess ","delete-vmess"), 
Button.inline(" Renew Vmess ","renew-vmess")], 
[Button.inline(" Check User Login ","cek-vmess"),
Button.inline(" Check Config ","cfg-vmess")],
[Button.inline(" Change Limit IP ","vm-ip"), 
Button.inline(" Change Limit Quota ","vm-quota")], 
[Button.inline(" Locked Vmess ","lvm"), 
Button.inline(" Unlocked Vmess ","uvm")], 
[Button.inline(" List Member ","memvm"), 
Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
        **⟨ XRAY/VMESS ⟩**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `VMESS`
🔰 **» Domain:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **» t.me/nauracloud/30**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)