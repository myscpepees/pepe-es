from xdxl import *

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = username.raw_text
            
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (days):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")
        
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = f'printf "%s\n" "{username}" "{quota}" "{iplim}" "{exp}" | addvl add bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Add Xray/Vless Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{username}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{uuid}`
**» Security :** `none`
**» NetWork :** `ws - grpc`
**» Path :** `/vless`
**» ServiceName  :** `vless`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vless-{username}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{later}`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    async def trial_vless_(event):
        async with bot.conversation(chat) as conv:
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (menit):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")
        
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Trial Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = f'printf "%s\n" "{quota}" "{iplim}" "{exp}" | addvl trial bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            user = re.search("#(.*)",x[0]).group(1)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Trial Xray/Vless Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{uuid}`
**» Security :** `none`
**» NetWork :** `ws - grpc`
**» Path :** `/vless`
**» ServiceName  :** `vless`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vless-{user}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp} minutes`
**» 🤖 t.me/nauracloud/30`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)