from xdxl import *

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = username.raw_text
            
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (days):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{username}" "{quota}" "{iplim}" "{exp}" | addvm add bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)",a)]
            print(b)
            z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
            z = json.loads(z)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Add Xray/Vmess Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{z["ps"]}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{z["id"]}`
**» AlterId :** `0`
**» Security :** `auto`
**» NetWork :** `ws - grpc`
**» Path :** `/vmess`
**» ServiceName  :** `vmess`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS :** 
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link gRPC :** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vmess-{username}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{later}`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as conv:
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (menit):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")
            
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Trial Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{quota}" "{iplim}" "{exp}" | addvm trial bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            b = [x.group() for x in re.finditer("vmess://(.*)",a)]
            print(b)
            z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
            z = json.loads(z)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Trial Xray/Vmess Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{z["ps"]}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{z["id"]}`
**» AlterId :** `0`
**» Security :** `auto`
**» NetWork :** `ws - grpc`
**» Path :** `/vmess`
**» ServiceName  :** `vmess`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS :** 
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link gRPC :** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vmess-{z["ps"]}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp} menit`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)