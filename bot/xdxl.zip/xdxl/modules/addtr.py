from xdxl import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = username.raw_text
            
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (days):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")
        
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = f'printf "%s\n" "{username}" "{quota}" "{iplim}" "{exp}" | addtr add bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("trojan://(.*)",a)]
            print(b)
            domain = re.search("@(.*?):",b[0]).group(1)
            uuid = re.search("trojan://(.*?)@",b[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Add Xray/Trojan Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{username}`
**» Host/Ip :** `{domain}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port NTLS :** `80`
**» Port TLS :** `443`
**» Port gRPC :** `443`
**» Key :** `{uuid}`
**» NetWork :** `ws - grpc`
**» Path :** `/trojan`
**» ServiceName  :** `trojan`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS   :** 
```{b[0].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :** 
```{b[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
```{b[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{domain}:81/trojan-{username}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{later}`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        async with bot.conversation(chat) as conv:
            # Quota input with number validation
            while True:
                await event.respond("**Quota (GB):**")
                quota = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota.raw_text
                if quota.isdigit():
                    break
                await event.respond("**Error:** Masukan Quota hanya angka. Silahkan coba lagi.")
            
            # Limit IP input with number validation
            while True:
                await event.respond("**Limit IP:**")
                iplim = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplim = iplim.raw_text
                if iplim.isdigit():
                    break
                await event.respond("**Error:** Masukan Limit IP hanya angka. Silahkan coba lagi.")
                
            # Expired input with number validation
            while True:
                await event.respond("**Expired (menit):**")
                exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp.raw_text
                if exp.isdigit():
                    break
                await event.respond("**Error:** Masukan Expired hanya angka. Silahkan coba lagi.")
        
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Trial Account`")
        time.sleep(2)
        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = f'printf "%s\n" "{quota}" "{iplim}" "{exp}" | addtr trial bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            b = [x.group() for x in re.finditer("trojan://(.*)",a)]
            print(b)
            user = re.search("#(.*)",b[0]).group(1)
            domain = re.search("@(.*?):",b[0]).group(1)
            uuid = re.search("trojan://(.*?)@",b[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Trial Xray/Trojan Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Host/Ip :** `{domain}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port NTLS :** `80`
**» Port TLS :** `443`
**» Port gRPC :** `443`
**» Key :** `{uuid}`
**» NetWork :** `ws - grpc`
**» Path :** `/trojan`
**» ServiceName  :** `trojan`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS   :** 
```{b[0].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :** 
```{b[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
```{b[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{domain}:81/trojan-{user}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp} minutes`
**» 🤖 t.me/nauracloud/30`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)